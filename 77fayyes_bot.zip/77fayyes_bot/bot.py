import asyncio
import logging
from aiogram import Bot, Dispatcher
from aiogram.enums import ParseMode
from aiogram.client.default import DefaultBotProperties

from config import BOT_TOKEN
from database import init_db
from handlers_admin import router as admin_router
from handlers_user import router as user_router

async def main():
    # Настраиваем логирование
    logging.basicConfig(level=logging.INFO)

    # Инициализируем базу данных (создаем таблицы, если их нет)
    await init_db()

    # Создаем объект бота с дефолтным парсингом HTML
    bot = Bot(
        token=BOT_TOKEN,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML)
    )
    
    dp = Dispatcher()

    # Подключаем роутеры (админский должен быть первым для приоритета)
    dp.include_router(admin_router)
    dp.include_router(user_router)

    print("🤖 Бот успешно запущен и готов к работе!")

    # Сбрасываем накопленные апдейты и запускаем polling
    await bot.delete_webhook(drop_pending_updates=True)
    await dp.start_polling(bot)

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        print("🤖 Бот остановлен.")