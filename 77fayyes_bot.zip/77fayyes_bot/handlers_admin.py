from aiogram import Router, F
from aiogram.types import Message, CallbackQuery, ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.filters import Command, StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
import json
import aiosqlite
from config import DATABASE_FILE

from config import ADMIN_ID
from database import set_maintenance_mode, is_maintenance_mode, set_running_line, get_running_line, delete_running_line

router = Router()
# Фильтр: пускаем только админа
router.message.filter(F.from_user.id == ADMIN_ID)
router.callback_query.filter(F.from_user.id == ADMIN_ID)

# --- Машина состояний для админа ---
class AdminStates(StatesGroup):
    waiting_for_running_line = State()
    
    # Состояния для создания товара
    add_title = State()
    add_price = State()
    add_description = State()
    add_category = State()
    add_colors = State() # Выбор цветов
    add_sizes = State()  # Ввод размеров для каждого цвета
    add_photo_front = State()
    add_photo_back = State()
    add_measurements = State()
    add_drop_collection = State()

# --- Главное меню админа ---
def get_admin_main_kb():
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="📦 Управление товарами")],
            [KeyboardButton(text="🛒 Заказы"), KeyboardButton(text="⚙️ Настройки")]
        ],
        resize_keyboard=True
    )

@router.message(Command("admin"))
async def cmd_admin(message: Message, state: FSMContext):
    await state.clear()
    await message.answer(
        "👋 Добро пожаловать в панель администратора.",
        reply_markup=get_admin_main_kb()
    )

# --- НАСТРОЙКИ ---
@router.message(F.text == "⚙️ Настройки")
async def settings_menu(message: Message):
    is_closed = is_maintenance_mode()
    status_text = "🔴 ЗАКРЫТ (Тех. перерыв)" if is_closed else "🟢 ОТКРЫТ"
    
    running_line = await get_running_line()
    rl_text = f"✅ Активна: {running_line}" if running_line else "❌ Не активна"

    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔄 Изменить статус сайта", callback_data="toggle_maintenance")],
        [InlineKeyboardButton(text="➕ Добавить бегущую строку" if not running_line else "🗑 Удалить бегущую строку", callback_data="toggle_running_line")]
    ])

    await message.answer(
        f"<b>⚙️ Настройки сайта:</b>\n\n"
        f"Статус сайта: {status_text}\n"
        f"Бегущая строка: {rl_text}",
        reply_markup=kb,
        parse_mode="HTML"
    )

@router.callback_query(F.data == "toggle_maintenance")
async def process_toggle_maintenance(callback: CallbackQuery):
    is_closed = is_maintenance_mode()
    set_maintenance_mode(not is_closed) # Меняем на противоположный
    
    # Пересобираем меню настроек с новыми данными
    new_is_closed = is_maintenance_mode()
    status_text = "🔴 ЗАКРЫТ (Тех. перерыв)" if new_is_closed else "🟢 ОТКРЫТ"
    running_line = await get_running_line()
    rl_text = f"✅ Активна: {running_line}" if running_line else "❌ Не активна"

    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔄 Изменить статус сайта", callback_data="toggle_maintenance")],
        [InlineKeyboardButton(text="➕ Добавить бегущую строку" if not running_line else "🗑 Удалить бегущую строку", callback_data="toggle_running_line")]
    ])

    await callback.message.edit_text(
        f"<b>⚙️ Настройки сайта:</b>\n\n"
        f"Статус сайта: {status_text}\n"
        f"Бегущая строка: {rl_text}",
        reply_markup=kb,
        parse_mode="HTML"
    )
    await callback.answer("Статус сайта изменен!")

@router.callback_query(F.data == "toggle_running_line")
async def process_toggle_running_line(callback: CallbackQuery, state: FSMContext):
    running_line = await get_running_line()
    
    if running_line:
        # Если есть - удаляем
        await delete_running_line()
        await callback.answer("Бегущая строка удалена!")
        # Обновляем сообщение (вызываем settings_menu по сути, но через edit)
        await process_toggle_maintenance(callback) # Хак для быстрого обновления сообщения без дублирования кода
    else:
        # Если нет - просим текст
        await state.set_state(AdminStates.waiting_for_running_line)
        
        kb = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="🔙 Отмена", callback_data="cancel_setting")]
        ])
        await callback.message.edit_text("✍️ Введите текст для бегущей строки:", reply_markup=kb)

@router.message(StateFilter(AdminStates.waiting_for_running_line))
async def process_running_line_text(message: Message, state: FSMContext):
    await set_running_line(message.text)
    await state.clear()
    await message.answer("✅ Бегущая строка успешно установлена!")
    await settings_menu(message) # Возвращаем в меню настроек

@router.callback_query(F.data == "cancel_setting")
async def cancel_setting(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    await callback.answer("Действие отменено.")
    
    # Возвращаем в настройки
    is_closed = is_maintenance_mode()
    status_text = "🔴 ЗАКРЫТ (Тех. перерыв)" if is_closed else "🟢 ОТКРЫТ"
    running_line = await get_running_line()
    rl_text = f"✅ Активна: {running_line}" if running_line else "❌ Не активна"

    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔄 Изменить статус сайта", callback_data="toggle_maintenance")],
        [InlineKeyboardButton(text="➕ Добавить бегущую строку" if not running_line else "🗑 Удалить бегущую строку", callback_data="toggle_running_line")]
    ])
    await callback.message.edit_text(
        f"<b>⚙️ Настройки сайта:</b>\n\n"
        f"Статус сайта: {status_text}\n"
        f"Бегущая строка: {rl_text}",
        reply_markup=kb,
        parse_mode="HTML"
    )

# Расширяем FSM для создания и редактирования товаров
class ProductCreateStates(StatesGroup):
    title = State()
    price = State()
    description = State()
    category = State()
    colors = State()
    sizes = State()
    photo_front = State()
    photo_back = State()
    measurements = State()
    drop = State()

class ProductEditStates(StatesGroup):
    new_price = State()
    new_title = State()
    new_description = State()
    new_discount = State()
    select_color_sizes = State()
    new_sizes = State()

# Вспомогательная функция распарсить размер ("L-5, M-10" -> {"L": 5, "M": 10})
def parse_sizes(sizes_str: str) -> dict:
    sizes_dict = {}
    parts = sizes_str.split(",")
    for part in parts:
        if "-" in part:
            size, count = part.split("-", 1)
            sizes_dict[size.strip().upper()] = int(count.strip())
    return sizes_dict

# --- УПРАВЛЕНИЕ ТОВАРАМИ (ГЛАВНОЕ МЕНЮ БОТА) ---
@router.message(F.text == "📦 Управление товарами")
async def products_menu(message: Message):
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="➕ Создать товар", callback_data="admin_create_product")],
        [InlineKeyboardButton(text="📋 Список товаров", callback_data="admin_list_products")]
    ])
    await message.answer("<b>📦 Управление товарами:</b>", reply_markup=kb, parse_mode="HTML")

# ==========================================
# СОЗДАНИЕ ТОВАРА
# ==========================================
@router.callback_query(F.data == "admin_create_product")
async def start_create_product(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    await state.set_state(ProductCreateStates.title)
    await callback.message.edit_text("✍️ Введите <b>название товара</b>:", parse_mode="HTML")

@router.message(StateFilter(ProductCreateStates.title))
async def process_title(message: Message, state: FSMContext):
    await state.update_data(title=message.text)
    await state.set_state(ProductCreateStates.price)
    await message.answer("💰 Введите <b>цену товара</b> (только число, например: 1200):", parse_mode="HTML")

@router.message(StateFilter(ProductCreateStates.price))
async def process_price(message: Message, state: FSMContext):
    try:
        price = float(message.text.replace(",", "."))
        await state.update_data(price=price)
        await state.set_state(ProductCreateStates.description)
        await message.answer("📝 Введите <b>описание товара</b>:", parse_mode="HTML")
    except ValueError:
        await message.answer("❌ Ошибка! Введите корректное число для цены.")

@router.message(StateFilter(ProductCreateStates.description))
async def process_description(message: Message, state: FSMContext):
    await state.update_data(description=message.text)
    await state.set_state(ProductCreateStates.category)
    
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="Футболка", callback_data="cat_Футболка"), InlineKeyboardButton(text="Лонгслив", callback_data="cat_Лонгслив")],
        [InlineKeyboardButton(text="Штаны", callback_data="cat_Штаны"), InlineKeyboardButton(text="Худи", callback_data="cat_Худи")]
    ])
    await message.answer("🏷 Выберите <b>тип товара</b>:", reply_markup=kb, parse_mode="HTML")

@router.callback_query(F.data.startswith("cat_"), StateFilter(ProductCreateStates.category))
async def process_category(callback: CallbackQuery, state: FSMContext):
    category = callback.data.split("_")[1]
    await state.update_data(category=category, selected_colors=[], variants=[])
    await state.set_state(ProductCreateStates.colors)
    
    await show_color_selection(callback.message, [])

async def show_color_selection(message: Message, selected_colors: list):
    all_colors = ["Белый", "Серый", "Черный"]
    buttons = []
    
    for color in all_colors:
        mark = "✅ " if color in selected_colors else ""
        buttons.append([InlineKeyboardButton(text=f"{mark}{color}", callback_data=f"toggle_color_{color}")])
    
    if selected_colors:
        buttons.append([InlineKeyboardButton(text="➡️ Далее к размерам", callback_data="colors_done")])
        
    kb = InlineKeyboardMarkup(inline_keyboard=buttons)
    await message.edit_text("🎨 Выберите доступные <b>цвета товара</b> (можно несколько):", reply_markup=kb, parse_mode="HTML")

@router.callback_query(F.data.startswith("toggle_color_"), StateFilter(ProductCreateStates.colors))
async def process_toggle_color(callback: CallbackQuery, state: FSMContext):
    color = callback.data.replace("toggle_color_", "")
    data = await state.get_data()
    selected_colors = data.get("selected_colors", [])
    
    if color in selected_colors:
        selected_colors.remove(color)
    else:
        selected_colors.append(color)
        
    await state.update_data(selected_colors=selected_colors)
    await show_color_selection(callback.message, selected_colors)

@router.callback_query(F.data == "colors_done", StateFilter(ProductCreateStates.colors))
async def process_colors_done(callback: CallbackQuery, state: FSMContext):
    data = await state.get_data()
    selected_colors = data.get("selected_colors", [])
    
    # Готовим очередь обработки каждого цвета
    await state.update_data(colors_queue=selected_colors.copy(), current_color_index=0)
    await ask_next_color_sizes(callback.message, state)

async def ask_next_color_sizes(message: Message, state: FSMContext):
    data = await state.get_data()
    queue = data["colors_queue"]
    index = data["current_color_index"]
    
    if index < len(queue):
        current_color = queue[index]
        await state.set_state(ProductCreateStates.sizes)
        text = (
            f"📏 Укажите наличие размеров для цвета <b>{current_color}</b>.\n\n"
            f"Формат ввода через запятую: <code>S-5, M-10, L-0</code>"
        )
        if isinstance(message, CallbackQuery):
            await message.message.edit_text(text, parse_mode="HTML")
        else:
            await message.answer(text, parse_mode="HTML")
    else:
        # Все цвета обработаны, переходим к фото
        await state.update_data(current_color_index=0)
        await ask_next_color_photos(message, state, photo_type="front")

@router.message(StateFilter(ProductCreateStates.sizes))
async def process_sizes_input(message: Message, state: FSMContext):
    try:
        sizes_dict = parse_sizes(message.text)
        if not sizes_dict:
            raise ValueError
        
        data = await state.get_data()
        variants = data.get("variants", [])
        current_color = data["colors_queue"][data["current_color_index"]]
        
        variants.append({
            "color": current_color,
            "sizes": sizes_dict,
            "photo_front": None,
            "photo_back": None
        })
        
        await state.update_data(variants=variants, current_color_index=data["current_color_index"] + 1)
        await ask_next_color_sizes(message, state)
    except Exception:
        await message.answer("❌ Неверный формат! Введите строго по шаблону, например: <code>S-5, M-10, L-2</code>", parse_mode="HTML")

async def ask_next_color_photos(message: Message, state: FSMContext, photo_type: str):
    data = await state.get_data()
    variants = data["variants"]
    index = data["current_color_index"]
    
    if index < len(variants):
        current_color = variants[index]["color"]
        if photo_type == "front":
            await state.set_state(ProductCreateStates.photo_front)
            await message.answer(f"📸 Отправьте фото <b>СПЕРЕДИ</b> для цвета <b>{current_color}</b>:", parse_mode="HTML")
        else:
            await state.set_state(ProductCreateStates.photo_back)
            await message.answer(f"📸 Отправьте фото <b>СЗАДИ</b> для цвета <b>{current_color}</b>:", parse_mode="HTML")
    else:
        # Все фото загружены, переходим к замерам
        await state.set_state(ProductCreateStates.measurements)
        await message.answer("📐 Отправьте <b>фото замеров</b> для этого товара:", parse_mode="HTML")

@router.message(StateFilter(ProductCreateStates.photo_front), F.photo)
async def process_photo_front(message: Message, state: FSMContext):
    photo_id = message.photo[-1].file_id
    data = await state.get_data()
    index = data["current_color_index"]
    data["variants"][index]["photo_front"] = photo_id
    await state.update_data(variants=data["variants"])
    
    await ask_next_color_photos(message, state, photo_type="back")

@router.message(StateFilter(ProductCreateStates.photo_back), F.photo)
async def process_photo_back(message: Message, state: FSMContext):
    photo_id = message.photo[-1].file_id
    data = await state.get_data()
    index = data["current_color_index"]
    data["variants"][index]["photo_back"] = photo_id
    
    # Переходим к следующему цвету или к замерам
    await state.update_data(variants=data["variants"], current_color_index=index + 1)
    await ask_next_color_photos(message, state, photo_type="front")

@router.message(StateFilter(ProductCreateStates.measurements), F.photo)
async def process_measurements(message: Message, state: FSMContext):
    photo_id = message.photo[-1].file_id
    await state.update_data(measurements_photo=photo_id)
    await state.set_state(ProductCreateStates.drop)
    await message.answer("🏷 Напишите <b>название коллекции / дропа</b> (например: Summer Drop 2026):", parse_mode="HTML")

@router.message(StateFilter(ProductCreateStates.drop))
async def process_drop_collection(message: Message, state: FSMContext):
    drop_name = message.text
    data = await state.get_data()
    
    # Сохраняем товар в БД
    async with aiosqlite.connect(DATABASE_FILE) as db:
        cursor = await db.execute("""
            INSERT INTO products (title, price, description, category, drop_collection, measurements_photo)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (data["title"], data["price"], data["description"], data["category"], drop_name, data["measurements_photo"]))
        
        product_id = cursor.lastrowid
        
        for v in data["variants"]:
            await db.execute("""
                INSERT INTO product_variants (product_id, color, sizes_stock, photo_front, photo_back)
                VALUES (?, ?, ?, ?, ?)
            """, (product_id, v["color"], json.dumps(v["sizes"]), v["photo_front"], v["photo_back"]))
            
        await db.commit()
        
    await state.clear()
    await message.answer("✅ <b>Товар успешно создан и добавлен в базу данных!</b>", parse_mode="HTML")

# ==========================================
# СПИСОК И РЕДАКТИРОВАНИЕ ТОВАРОВ
# ==========================================
@router.callback_query(F.data == "admin_list_products")
async def list_products(callback: CallbackQuery):
    async with aiosqlite.connect(DATABASE_FILE) as db:
        async with db.execute("SELECT id, title, price, is_hidden FROM products ORDER BY id DESC") as cursor:
            products = await cursor.fetchall()
            
    if not products:
        await callback.message.edit_text("📭 Список товаров пуст.")
        return
        
    buttons = []
    for p_id, title, price, is_hidden in products:
        status = " [СКРЫТ]" if is_hidden else ""
        buttons.append([InlineKeyboardButton(text=f"{title} — {price} UAH{status}", callback_data=f"prod_view_{p_id}")])
        
    kb = InlineKeyboardMarkup(inline_keyboard=buttons)
    await callback.message.edit_text("<b>📋 Список всех товаров:</b>\nВыберите товар для настроек:", reply_markup=kb, parse_mode="HTML")

@router.callback_query(F.data.startswith("prod_view_"))
async def view_product(callback: CallbackQuery):
    product_id = int(callback.data.replace("prod_view_", ""))
    
    async with aiosqlite.connect(DATABASE_FILE) as db:
        async with db.execute("SELECT id, title, price, discount_price, description, category, drop_collection, is_hidden FROM products WHERE id = ?", (product_id,)) as cursor:
            product = await cursor.fetchone()
            
        async with db.execute("SELECT color, sizes_stock FROM product_variants WHERE product_id = ?", (product_id,)) as cursor:
            variants = await cursor.fetchall()
            
    if not product:
        await callback.answer("Товар не найден!")
        return
        
    p_id, title, price, discount, desc, cat, drop, is_hidden = product
    price_text = f"<s>{price}</s> {discount} UAH" if discount else f"{price} UAH"
    
    var_text = ""
    for color, sizes_json in variants:
        sizes = json.loads(sizes_json)
        sizes_str = ", ".join([f"{s}-{c}" for s, c in sizes.items()])
        var_text += f"• <b>{color}:</b> {sizes_str}\n"
        
    text = (
        f"<b>📦 {title}</b>\n\n"
        f"Категория: {cat}\n"
        f"Коллекция: {drop}\n"
        f"Цена: {price_text}\n"
        f"Статус: {'🔴 Скрыт' if is_hidden else '🟢 Виден на сайте'}\n\n"
        f"<b>Наличие:</b>\n{var_text}\n"
        f"<b>Описание:</b>\n{desc}"
    )
    
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✏️ Изменить цену", callback_data=f"edit_price_{p_id}"), InlineKeyboardButton(text="🏷 Скидка", callback_data=f"edit_disc_{p_id}")],
        [InlineKeyboardButton(text="✏️ Изменить название", callback_data=f"edit_title_{p_id}"), InlineKeyboardButton(text="✏️ Изменить описание", callback_data=f"edit_desc_{p_id}")],
        [InlineKeyboardButton(text="📏 Изменить размеры/наличие", callback_data=f"edit_sizes_{p_id}")],
        [InlineKeyboardButton(text="👁 " + ("Показать" if is_hidden else "Скрыть"), callback_data=f"toggle_hide_{p_id}"), InlineKeyboardButton(text="🗑 Удалить товар", callback_data=f"del_prod_{p_id}")],
        [InlineKeyboardButton(text="🔙 Назад к списку", callback_data="admin_list_products")]
    ])
    
    await callback.message.edit_text(text, reply_markup=kb, parse_mode="HTML")

@router.callback_query(F.data.startswith("toggle_hide_"))
async def toggle_hide_product(callback: CallbackQuery):
    product_id = int(callback.data.replace("toggle_hide_", ""))
    async with aiosqlite.connect(DATABASE_FILE) as db:
        await db.execute("UPDATE products SET is_hidden = CASE WHEN is_hidden = 1 THEN 0 ELSE 1 END WHERE id = ?", (product_id,))
        await db.commit()
    await view_product(callback)

@router.callback_query(F.data.startswith("del_prod_"))
async def confirm_delete_product(callback: CallbackQuery):
    product_id = int(callback.data.replace("del_prod_", ""))
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="❌ ДА, УДАЛИТЬ ПОЛНОСТЬЮ", callback_data=f"confirm_del_{product_id}")],
        [InlineKeyboardButton(text="🔙 Отмена", callback_data=f"prod_view_{product_id}")]
    ])
    await callback.message.edit_text("⚠️ <b>Вы уверены, что хотите удалить товар?</b> Это действие нельзя отменить!", reply_markup=kb, parse_mode="HTML")

@router.callback_query(F.data.startswith("confirm_del_"))
async def delete_product_final(callback: CallbackQuery):
    product_id = int(callback.data.replace("confirm_del_", ""))
    async with aiosqlite.connect(DATABASE_FILE) as db:
        await db.execute("DELETE FROM products WHERE id = ?", (product_id,))
        await db.commit()
    await callback.answer("Товар полностью удален!")
    await list_products(callback)

# ==========================================
# ЧАСТЬ 3: УПРАВЛЕНИЕ ЗАКАЗАМИ
# ==========================================

class OrderAdminStates(StatesGroup):
    waiting_for_ttn = State()
    waiting_for_new_phone = State()

ITEMS_PER_PAGE = 5

async def notify_buyer(bot, user_phone: str, message_text: str):
    """Вспомогательная функция для отправки сообщений покупателю через его Telegram ID"""
    async with aiosqlite.connect(DATABASE_FILE) as db:
        async with db.execute("SELECT telegram_id FROM users WHERE phone = ?", (user_phone,)) as cursor:
            row = await cursor.fetchone()
            if row and row[0]:
                try:
                    await bot.send_message(chat_id=row[0], text=message_text, parse_mode="HTML")
                except Exception:
                    pass # Если пользователь заблокировал бота

@router.message(F.text == "🛒 Заказы")
async def orders_menu(message: Message):
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="⏳ Ожидающие заказы", callback_data="orders_list_pending_0")],
        [InlineKeyboardButton(text="✅ Подтвержденные", callback_data="orders_list_confirmed_0")],
        [InlineKeyboardButton(text="🚚 С ТТН / В пути", callback_data="orders_list_shipped_0")],
        [InlineKeyboardButton(text="❌ Отмененные", callback_data="orders_list_cancelled_0")]
    ])
    await message.answer("<b>🛒 Управление заказами:</b>\nВыберите категорию заказов:", reply_markup=kb, parse_mode="HTML")

@router.callback_query(F.data.startswith("orders_list_"))
async def list_orders_by_status(callback: CallbackQuery):
    # Разбираем callback: orders_list_{status}_{page}
    parts = callback.data.split("_")
    status_type = parts[2]
    page = int(parts[3])

    status_filter = {
        "pending": "status = 'pending'",
        "confirmed": "status = 'confirmed'",
        "shipped": "status IN ('ttn_created', 'packed', 'shipped') AND (status != 'shipped' OR created_at >= datetime('now', '-1 day'))",
        "cancelled": "status = 'cancelled'"
    }.get(status_type, "status = 'pending'")

    async with aiosqlite.connect(DATABASE_FILE) as db:
        async with db.execute(f"SELECT COUNT(*) FROM orders WHERE {status_filter}") as cursor:
            total_count = (await cursor.fetchone())[0]

        offset = page * ITEMS_PER_PAGE
        async with db.execute(
            f"SELECT id, full_name, total_price, product_title, status FROM orders WHERE {status_filter} ORDER BY id DESC LIMIT ? OFFSET ?",
            (ITEMS_PER_PAGE, offset)
        ) as cursor:
            orders = await cursor.fetchall()

    if not orders:
        kb = InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="🔙 К категориям", callback_data="admin_orders_main")]])
        await callback.message.edit_text("📭 В этой категории нет заказов.", reply_markup=kb)
        return

    status_labels = {
        "pending": "⏳ Ожидают",
        "confirmed": "✅ Подтверждены",
        "ttn_created": "📄 ТТН создана",
        "packed": "📦 Запаковано",
        "shipped": "🚚 Отправлено",
        "cancelled": "❌ Отменен"
    }

    buttons = []
    for o_id, name, price, p_title, st in orders:
        st_label = status_labels.get(st, st)
        buttons.append([InlineKeyboardButton(text=f"#{o_id} | {name} | {price} UAH ({st_label})", callback_data=f"ord_view_{o_id}_{status_type}_{page}")])

    # Пагинация (стрелочки)
    pagination_row = []
    if page > 0:
        pagination_row.append(InlineKeyboardButton(text="⬅️ Назад", callback_data=f"orders_list_{status_type}_{page - 1}"))
    if (page + 1) * ITEMS_PER_PAGE < total_count:
        pagination_row.append(InlineKeyboardButton(text="Вперед ➡️", callback_data=f"orders_list_{status_type}_{page + 1}"))

    if pagination_row:
        buttons.append(pagination_row)

    buttons.append([InlineKeyboardButton(text="🔙 К категориям заказов", callback_data="admin_orders_main")])

    kb = InlineKeyboardMarkup(inline_keyboard=buttons)
    await callback.message.edit_text(f"<b>📋 Список заказов (Стр. {page + 1}):</b>", reply_markup=kb, parse_mode="HTML")

@router.callback_query(F.data == "admin_orders_main")
async def back_to_orders_main(callback: CallbackQuery):
    await orders_menu(callback.message)

@router.callback_query(F.data.startswith("ord_view_"))
async def view_order_details(callback: CallbackQuery):
    parts = callback.data.split("_")
    order_id = int(parts[2])
    back_status = parts[3]
    back_page = int(parts[4])

    async with aiosqlite.connect(DATABASE_FILE) as db:
        async with db.execute("""
            SELECT id, user_phone, telegram_username, full_name, city, post_office, 
                   product_title, color, size, quantity, total_price, comment, status, ttn, created_at 
            FROM orders WHERE id = ?
        """, (order_id,)) as cursor:
            order = await cursor.fetchone()

    if not order:
        await callback.answer("Заказ не найден!")
        return

    o_id, phone, tg_user, name, city, post, p_title, color, size, qty, total, comment, status, ttn, created_at = order

    status_readable = {
        "pending": "⏳ Ожидает подтверждения",
        "confirmed": "✅ Подтвержден (оплачен)",
        "ttn_created": "📄 ТТН Создана",
        "packed": "📦 Запакован",
        "shipped": "🚚 Отправлен клиенту",
        "cancelled": "❌ Отменен"
    }.get(status, status)

    comment_text = f"\n<b>Комментарий:</b> {comment}" if comment else ""
    ttn_text = f"\n<b>ТТН:</b> <code>{ttn}</code>" if ttn else ""

    text = (
        f"<b>📦 Заказ #{o_id}</b>\n"
        f"<b>Статус:</b> {status_readable}\n"
        f"<b>Дата:</b> {created_at}\n\n"
        f"<b>Покупатель:</b> {name}\n"
        f"<b>Телефон:</b> {phone}\n"
        f"<b>Telegram:</b> @{tg_user if tg_user else 'не указан'}\n"
        f"<b>Город:</b> {city}\n"
        f"<b>Новая Почта:</b> {post}\n"
        f"{comment_text}{ttn_text}\n\n"
        f"<b>Товар:</b> {p_title}\n"
        f"<b>Цвет:</b> {color} | <b>Размер:</b> {size} | <b>Кол-во:</b> {qty} шт.\n"
        f"<b>Сумма к оплате:</b> <b>{total} UAH</b>"
    )

    buttons = []

    # Кнопки смены статуса в зависимости от текущего
    if status == "pending":
        buttons.append([InlineKeyboardButton(text="✅ Подтвердить оплату/заказ", callback_data=f"ord_status_{o_id}_confirmed")])
    elif status == "confirmed":
        buttons.append([InlineKeyboardButton(text="📝 Ввести ТТН", callback_data=f"ord_input_ttn_{o_id}")])
    elif status == "ttn_created":
        buttons.append([InlineKeyboardButton(text="📦 Отметить 'Запаковано'", callback_data=f"ord_status_{o_id}_packed")])
    elif status == "packed":
        buttons.append([InlineKeyboardButton(text="🚚 Отметить 'Отправлено'", callback_data=f"ord_status_{o_id}_shipped")])

    # Доп кнопки: Изменить телефон и Отменить заказ (на всех статусах, кроме 'отправлено')
    if status != "shipped" and status != "cancelled":
        buttons.append([
            InlineKeyboardButton(text="📱 Изменить тел.", callback_data=f"ord_change_phone_{o_id}"),
            InlineKeyboardButton(text="❌ Отменить заказ", callback_data=f"ord_status_{o_id}_cancelled")
        ])

    buttons.append([InlineKeyboardButton(text="🔙 Назад к списку", callback_data=f"orders_list_{back_status}_{back_page}")])

    kb = InlineKeyboardMarkup(inline_keyboard=buttons)
    await callback.message.edit_text(text, reply_markup=kb, parse_mode="HTML")

# --- СМЕНА СТАТУСОВ И УВЕДОМЛЕНИЯ ПОКУПАТЕЛЯ ---
@router.callback_query(F.data.startswith("ord_status_"))
async def change_order_status(callback: CallbackQuery):
    parts = callback.data.split("_")
    order_id = int(parts[2])
    new_status = parts[3]

    async with aiosqlite.connect(DATABASE_FILE) as db:
        async with db.execute("SELECT user_phone, ttn, product_title FROM orders WHERE id = ?", (order_id,)) as cursor:
            order = await cursor.fetchone()
        
        await db.execute("UPDATE orders SET status = ? WHERE id = ?", (new_status, order_id))
        await db.commit()

    user_phone, ttn, p_title = order

    # Тексты уведомлений клиенту
    if new_status == "confirmed":
        await notify_buyer(callback.bot, user_phone, f"✅ Ваш заказ <b>№{order_id}</b> ({p_title}) подтвержден! Готовим к отправке.")
    elif new_status == "packed":
        await notify_buyer(callback.bot, user_phone, f"📦 Ваш заказ <b>№{order_id}</b> успешно запакован и готов к передаче на почту!")
    elif new_status == "shipped":
        await notify_buyer(callback.bot, user_phone, f"🚚 Ваш заказ <b>№{order_id}</b> отправлен!\nТТН Новой Почты: <code>{ttn}</code>")
    elif new_status == "cancelled":
        await notify_buyer(callback.bot, user_phone, f"❌ Ваш заказ <b>№{order_id}</b> был отменен. Если у вас возникли вопросы, свяжитесь с поддержкой.")

    await callback.answer("Статус заказа обновлен!")
    await view_order_details(callback)

# --- ВВОД ТТН ---
@router.callback_query(F.data.startswith("ord_input_ttn_"))
async def start_input_ttn(callback: CallbackQuery, state: FSMContext):
    order_id = int(callback.data.replace("ord_input_ttn_", ""))
    await state.update_data(editing_order_id=order_id)
    await state.set_state(OrderAdminStates.waiting_for_ttn)
    await callback.message.edit_text(f"✍️ Введите номер ТТН для заказа <b>#{order_id}</b>:", parse_mode="HTML")

@router.message(StateFilter(OrderAdminStates.waiting_for_ttn))
async def process_ttn_input(message: Message, state: FSMContext):
    ttn_code = message.text.strip()
    data = await state.get_data()
    order_id = data["editing_order_id"]

    async with aiosqlite.connect(DATABASE_FILE) as db:
        async with db.execute("SELECT user_phone, product_title FROM orders WHERE id = ?", (order_id,)) as cursor:
            order = await cursor.fetchone()

        await db.execute("UPDATE orders SET ttn = ?, status = 'ttn_created' WHERE id = ?", (ttn_code, order_id))
        await db.commit()

    user_phone, p_title = order
    await notify_buyer(message.bot, user_phone, f"📄 Ваш заказ изменил статус! Накладная создана.\nВаша ТТН: <code>{ttn_code}</code>")

    await state.clear()
    await message.answer(f"✅ ТТН для заказа #{order_id} успешно сохранена, покупатель уведомлен!")

# --- ИЗМЕНЕНИЕ НОМЕРА ТЕЛЕФОНА В ЗАКАЗЕ ---
@router.callback_query(F.data.startswith("ord_change_phone_"))
async def start_change_phone(callback: CallbackQuery, state: FSMContext):
    order_id = int(callback.data.replace("ord_change_phone_", ""))
    await state.update_data(editing_order_id=order_id)
    await state.set_state(OrderAdminStates.waiting_for_new_phone)
    await callback.message.edit_text(f"📱 Введите новый номер телефона для заказа <b>#{order_id}</b>:", parse_mode="HTML")

@router.message(StateFilter(OrderAdminStates.waiting_for_new_phone))
async def process_new_phone_input(message: Message, state: FSMContext):
    new_phone = message.text.strip()
    data = await state.get_data()
    order_id = data["editing_order_id"]

    async with aiosqlite.connect(DATABASE_FILE) as db:
        await db.execute("UPDATE orders SET user_phone = ? WHERE id = ?", (new_phone, order_id))
        await db.commit()

    await state.clear()
    await message.answer(f"✅ Номер телефона в заказе #{order_id} обновлен на {new_phone}.")