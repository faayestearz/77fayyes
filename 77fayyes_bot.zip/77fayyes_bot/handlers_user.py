import os
import aiosqlite
from aiogram import Router, F
from aiogram.types import Message, CallbackQuery, ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton, WebAppInfo
from aiogram.filters import Command, StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup

from config import DATABASE_FILE, SUPPORT_CHAT_URL, INSTAGRAM_URL, TELEGRAM_CHANNEL_URL, ADMIN_ID

# Ссылка на твой WebApp
WEB_APP_URL = os.getenv("WEB_APP_URL", "https://tvo-domen.com/catalog")

router = Router()

class UserStates(StatesGroup):
    waiting_for_phone = State()

def get_user_main_kb():
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="🛍 Відкрити каталог", web_app=WebAppInfo(url=WEB_APP_URL))],
            [KeyboardButton(text="📦 Мої замовлення")],
            [KeyboardButton(text="💬 Зв'язатися з підтримкою"), KeyboardButton(text="🌐 Наші соц мережі")]
        ],
        resize_keyboard=True
    )

# ==========================================
# АВТОРИЗАЦИЯ И СТАРТ
# ==========================================
@router.message(Command("start"))
async def cmd_start_user(message: Message, state: FSMContext):
    # Если зашел админ — мягко намекаем, что ему нужна другая команда
    if message.from_user.id == ADMIN_ID:
        await message.answer("Ви адміністратор бренду. Натисніть /admin для входу в панель керування.")
        return

    # Проверяем, привязан ли уже Telegram ID к аккаунту
    async with aiosqlite.connect(DATABASE_FILE) as db:
        async with db.execute("SELECT id, phone, full_name FROM users WHERE telegram_id = ?", (message.from_user.id,)) as cursor:
            user = await cursor.fetchone()

    if user:
        # Пользователь уже авторизован
        await message.answer(f"👋 Вітаємо знову, {user[2]}!\nОсь ваше головне меню:", reply_markup=get_user_main_kb())
    else:
        # Просим номер телефона для связки с БД
        await state.set_state(UserStates.waiting_for_phone)
        kb = ReplyKeyboardMarkup(
            keyboard=[[KeyboardButton(text="📱 Надіслати номер телефону", request_contact=True)]],
            resize_keyboard=True,
            one_time_keyboard=True
        )
        await message.answer(
            "Привіт! 👋\nЩоб увійти в особистий кабінет та переглядати статус своїх замовлень, будь ласка, поділіться номером телефону (кнопка нижче) або впишіть його вручну у форматі 380...",
            reply_markup=kb
        )

@router.message(StateFilter(UserStates.waiting_for_phone), F.contact | F.text)
async def process_phone_login(message: Message, state: FSMContext):
    if message.contact:
        phone = message.contact.phone_number
    else:
        phone = message.text.strip().replace("+", "") # Приводим к единому формату без плюса
        
    async with aiosqlite.connect(DATABASE_FILE) as db:
        # Ищем пользователя, которого создал сайт при оформлении заказа
        async with db.execute("SELECT id, full_name FROM users WHERE phone = ?", (phone,)) as cursor:
            user = await cursor.fetchone()

        if user:
            # Привязываем telegram_id к аккаунту
            await db.execute("UPDATE users SET telegram_id = ? WHERE phone = ?", (message.from_user.id, phone))
            await db.commit()
            
            async with db.execute("SELECT COUNT(*) FROM orders WHERE user_phone = ?", (phone,)) as cursor:
                orders_count = (await cursor.fetchone())[0]

            await state.clear()
            await message.answer(
                f"✅ <b>Авторизація успішна!</b>\nРаді бачити вас, {user[1]}.\nКількість ваших замовлень: <b>{orders_count}</b>.",
                reply_markup=get_user_main_kb(),
                parse_mode="HTML"
            )
        else:
            await state.clear()
            await message.answer(
                "❌ Ми не знайшли цей номер у базі покупців.\n"
                "Якщо ви ще не робили замовлень, просто відкрийте каталог і зробіть своє перше замовлення, акаунт створиться автоматично!",
                reply_markup=get_user_main_kb()
            )

# ==========================================
# ИНФО РАЗДЕЛЫ
# ==========================================
@router.message(F.text == "💬 Зв'язатися з підтримкою")
async def support_menu(message: Message):
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="💬 Написати менеджеру", url=SUPPORT_CHAT_URL)]
    ])
    await message.answer("Якщо у вас виникли запитання щодо замовлення, розмірів або доставки, наша підтримка завжди на зв'язку:", reply_markup=kb)

@router.message(F.text == "🌐 Наші соц мережі")
async def socials_menu(message: Message):
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📸 Instagram", url=INSTAGRAM_URL)],
        [InlineKeyboardButton(text="📢 Telegram-канал", url=TELEGRAM_CHANNEL_URL)]
    ])
    await message.answer("Слідкуйте за нашими новими колекціями та дропами у соцмережах:", reply_markup=kb)

# ==========================================
# МОИ ЗАКАЗЫ (СПИСОК И ДЕТАЛИ)
# ==========================================
@router.message(F.text == "📦 Мої замовлення")
async def my_orders_list(message: Message):
    async with aiosqlite.connect(DATABASE_FILE) as db:
        async with db.execute("SELECT phone FROM users WHERE telegram_id = ?", (message.from_user.id,)) as cursor:
            user_row = await cursor.fetchone()
            
        if not user_row:
            await message.answer("❌ Ви не авторизовані. Натисніть /start для входу в акаунт.")
            return
            
        phone = user_row[0]
        async with db.execute("SELECT id, product_title, status FROM orders WHERE user_phone = ? ORDER BY id DESC", (phone,)) as cursor:
            orders = await cursor.fetchall()
            
    if not orders:
        await message.answer("📭 У вас поки немає замовлень. Відкривайте каталог та обирайте стильні речі!")
        return
        
    status_labels = {
        "pending": "⏳ Очікує",
        "confirmed": "✅ Підтверджено",
        "ttn_created": "📄 ТТН",
        "packed": "📦 Запаковано",
        "shipped": "🚚 Відправлено",
        "cancelled": "❌ Скасовано"
    }
    
    buttons = []
    for o_id, title, status in orders:
        st = status_labels.get(status, status)
        buttons.append([InlineKeyboardButton(text=f"№{o_id} | {title} | {st}", callback_data=f"usr_ord_view_{o_id}")])
        
    kb = InlineKeyboardMarkup(inline_keyboard=buttons)
    await message.answer("<b>📦 Ваші замовлення:</b>\nНатисніть на замовлення для перегляду деталей.", reply_markup=kb, parse_mode="HTML")

@router.callback_query(F.data.startswith("usr_ord_view_"))
async def user_order_details(callback: CallbackQuery):
    order_id = int(callback.data.replace("usr_ord_view_", ""))
    
    async with aiosqlite.connect(DATABASE_FILE) as db:
        async with db.execute("""
            SELECT id, product_title, color, size, quantity, total_price, status, ttn, created_at, city, post_office 
            FROM orders WHERE id = ?
        """, (order_id,)) as cursor:
            order = await cursor.fetchone()
            
    if not order:
        await callback.answer("Замовлення не знайдено!", show_alert=True)
        return
        
    o_id, title, color, size, qty, total, status, ttn, created_at, city, post = order
    
    status_readable = {
        "pending": "⏳ Очікує підтвердження",
        "confirmed": "✅ Підтверджено (оплачено)",
        "ttn_created": "📄 ТТН Створена (скоро відправка)",
        "packed": "📦 Запаковано (готується до відправки)",
        "shipped": "🚚 Відправлено",
        "cancelled": "❌ Скасовано"
    }.get(status, status)
    
    ttn_text = f"\n<b>ТТН Нової Пошти:</b> <code>{ttn}</code>" if ttn else ""
    
    text = (
        f"<b>📦 Замовлення #{o_id}</b>\n"
        f"<b>Статус:</b> {status_readable}\n"
        f"<b>Дата створення:</b> {created_at}\n\n"
        f"<b>Товар:</b> {title}\n"
        f"<b>Колір:</b> {color} | <b>Розмір:</b> {size} | <b>Кількість:</b> {qty} шт.\n\n"
        f"<b>Доставка:</b> м. {city}, Відділення {post}"
        f"{ttn_text}\n\n"
        f"<b>Загальна сума:</b> {total} UAH"
    )
    
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔙 Назад до списку", callback_data="usr_orders_back")]
    ])
    
    await callback.message.edit_text(text, reply_markup=kb, parse_mode="HTML")

@router.callback_query(F.data == "usr_orders_back")
async def user_orders_back(callback: CallbackQuery):
    # Восстанавливаем список инлайн кнопок без отправки нового сообщения
    async with aiosqlite.connect(DATABASE_FILE) as db:
        async with db.execute("SELECT phone FROM users WHERE telegram_id = ?", (callback.from_user.id,)) as cursor:
            user_row = await cursor.fetchone()
            
        if not user_row:
            await callback.answer("Помилка авторизації.")
            return
            
        phone = user_row[0]
        async with db.execute("SELECT id, product_title, status FROM orders WHERE user_phone = ? ORDER BY id DESC", (phone,)) as cursor:
            orders = await cursor.fetchall()
            
    status_labels = {
        "pending": "⏳ Очікує",
        "confirmed": "✅ Підтверджено",
        "ttn_created": "📄 ТТН",
        "packed": "📦 Запаковано",
        "shipped": "🚚 Відправлено",
        "cancelled": "❌ Скасовано"
    }
    
    buttons = []
    for o_id, title, status in orders:
        st = status_labels.get(status, status)
        buttons.append([InlineKeyboardButton(text=f"№{o_id} | {title} | {st}", callback_data=f"usr_ord_view_{o_id}")])
        
    kb = InlineKeyboardMarkup(inline_keyboard=buttons)
    await callback.message.edit_text("<b>📦 Ваші замовлення:</b>\nНатисніть на замовлення для перегляду деталей.", reply_markup=kb, parse_mode="HTML")