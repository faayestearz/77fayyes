(function(){
    var brand = document.getElementById('brand'), name = document.getElementById('name'), nav = document.getElementById('nav'), catalog = document.getElementById('catalog');
    var ctaWrap = document.getElementById('ctaWrap'), hero = document.getElementById('hero'), footer = document.getElementById('footer');
    var panel = document.getElementById('fullPage'), openBtn = document.getElementById('openFull'), backBtn = document.getElementById('back');
    var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    var cur = 0, tgt = 0, raf = 0;

    function targetP(){
        var h = window.innerHeight, p = Math.min(1, Math.max(0, window.scrollY / h));
        return p * p * (3 - 2 * p);
    }
    function apply(p){
        var h = window.innerHeight, fs = parseFloat(getComputedStyle(name).fontSize) || 80;
        var endScale = Math.min(1, 26 / fs), endY = (window.innerWidth < 760 ? 64 : 40) - h / 2;
        brand.style.transform = 'translateY(' + (endY * p) + 'px) scale(' + (1 + (endScale - 1) * p) + ')';
    }
    function loop(){
        cur += (tgt - cur) * 0.07;
        if(Math.abs(tgt - cur) < 0.0005) cur = tgt;
        apply(cur);
        raf = (cur !== tgt) ? requestAnimationFrame(loop) : 0;
    }
    function onScroll(){
        if(document.body.classList.contains('full')) return;
        tgt = targetP();
        var top = catalog.getBoundingClientRect().top + window.scrollY;
        nav.classList.toggle('on', window.scrollY > top - window.innerHeight * 0.55);
        
        var o = 1 - Math.min(1, window.scrollY / (window.innerHeight * 0.3));
        ctaWrap.style.opacity = o;
        ctaWrap.style.pointerEvents = o < 0.2 ? 'none' : 'auto';
        if(!raf) raf = requestAnimationFrame(loop);
    }

    var anim = 0;
    function stopAnim(){ if(anim){ cancelAnimationFrame(anim); anim = 0; } }
    function scrollToY(y){
        stopAnim();
        var max = document.documentElement.scrollHeight - window.innerHeight;
        y = Math.max(0, Math.min(y, max));
        var start = window.scrollY, d = y - start;
        if(reduce || Math.abs(d) < 2){ window.scrollTo(0, y); return; }
        var ms = Math.min(2800, 1200 + Math.abs(d) * 0.9), t0 = null;
        function step(t){
            if(t0 === null) t0 = t;
            var k = Math.min(1, (t - t0) / ms);
            var e = k < .5 ? 4 * k * k * k : 1 - Math.pow(-2 * k + 2, 3) / 2;
            window.scrollTo(0, start + d * e);
            anim = k < 1 ? requestAnimationFrame(step) : 0;
        }
        anim = requestAnimationFrame(step);
    }
    
    ['wheel', 'touchstart', 'keydown'].forEach(function(ev){ window.addEventListener(ev, stopAnim, {passive: true}); });
    document.querySelectorAll('[data-go]').forEach(function(a){
        a.addEventListener('click', function(e){
            e.preventDefault();
            var el = document.getElementById(a.getAttribute('data-go'));
            scrollToY(el.getBoundingClientRect().top + window.scrollY);
        });
    });

    var homeParts = [nav, hero, catalog, footer];
    function setInert(v){ homeParts.forEach(function(el){ if(v) el.setAttribute('inert', ''); else el.removeAttribute('inert'); }); }
    function openFull(e){
        e.preventDefault(); stopAnim();
        panel.scrollTop = 0;
        document.body.classList.add('full');
        setInert(true); panel.setAttribute('aria-hidden', 'false');
        setTimeout(function(){ backBtn.focus({preventScroll: true}); }, 60);
    }
    function closeFull(){
        document.body.classList.remove('full');
        setInert(false); panel.setAttribute('aria-hidden', 'true');
        openBtn.focus({preventScroll: true});
    }
    
    openBtn.addEventListener('click', openFull);
    backBtn.addEventListener('click', closeFull);
    window.addEventListener('keydown', function(e){ if(e.key === 'Escape' && document.body.classList.contains('full')) closeFull(); });

    document.querySelectorAll('.opt').forEach(function(b){
        b.addEventListener('click', function(){ b.setAttribute('aria-pressed', b.getAttribute('aria-pressed') === 'true' ? 'false' : 'true'); });
    });

    // Функция модального окна товара
    function openProductModal(product) {
        let existingModal = document.getElementById('productModal');
        if (existingModal) existingModal.remove();

        let modal = document.createElement('div');
        modal.id = 'productModal';
        modal.className = 'product-modal active';

        let photo = product.media_urls && product.media_urls.length > 0 ? product.media_urls[0] : '';

        modal.innerHTML = `
            <div class="product-modal-content glass">
                <button class="modal-close" id="closeModal">&times;</button>
                <div style="width:100%; height: 380px; border-radius: 16px; background: url('${photo}') center/cover no-repeat; background-color: rgba(255,255,255,0.05);"></div>
                <div style="display: flex; flex-direction: column; justify-content: space-between;">
                    <div>
                        <h2 style="font-family: 'Unbounded', sans-serif; font-size: 20px; margin-bottom: 10px; color: #fff;">${product.title}</h2>
                        <p style="font-size: 16px; font-weight: 500; opacity: 0.9; margin-bottom: 15px; color: #fff;">${product.price} UAH</p>
                        <p style="font-size: 14px; opacity: 0.7; line-height: 1.5; margin-bottom: 20px; color: #fff;">${product.description || 'Опис товару відсутній.'}</p>
                        
                        <div style="font-size: 13px; font-weight: 500; opacity: 0.8; margin-bottom: 8px; color: #fff;">Розмір:</div>
                        <div class="modal-sizes" id="modalSizes"></div>
                    </div>
                    <button class="add-to-cart-btn" id="addToCartBtn">Додати в кошик</button>
                </div>
            </div>
        `;

        document.body.appendChild(modal);

        let standardSizes = ["XS", "S", "M", "L", "XL", "XXL"];
        let availableSizesSet = new Set();
        if (product.variants) {
            product.variants.forEach(v => {
                if (v.sizes) v.sizes.forEach(s => availableSizesSet.add(s));
            });
        }

        let sizesContainer = modal.querySelector('#modalSizes');
        let selectedSize = null;

        standardSizes.forEach(sz => {
            let btn = document.createElement('button');
            btn.className = 'size-btn';
            btn.textContent = sz;
            
            let isAvailable = availableSizesSet.has(sz);
            if (!isAvailable) {
                btn.classList.add('disabled');
            } else {
                btn.addEventListener('click', function() {
                    modal.querySelectorAll('.size-btn').forEach(b => b.classList.remove('selected'));
                    btn.classList.add('selected');
                    selectedSize = sz;
                });
            }
            sizesContainer.appendChild(btn);
        });

        function closeModalFunc() {
            modal.classList.remove('active');
            setTimeout(() => modal.remove(), 300);
        }

        modal.querySelector('#closeModal').addEventListener('click', closeModalFunc);
        modal.addEventListener('click', (e) => {
            if (e.target === modal) closeModalFunc();
        });

        modal.querySelector('#addToCartBtn').addEventListener('click', function() {
            if (!selectedSize) {
                alert('Будь ласка, виберіть розмір!');
                return;
            }
            alert(`Товар "${product.title}" (${selectedSize}) додано до кошика!`);
            closeModalFunc();
        });
    }

    // Загрузка товаров с FastAPI по абсолютному адресу
    async function loadProducts() {
        try {
            let res = await fetch('http://127.0.0.1:8000/api/products');
            let data = await res.json();
            let products = data.products || [];
            
            let grid = document.querySelector('.catalog .grid');
            if (!grid) return;
            
            grid.innerHTML = '';
            
            if (products.length === 0) {
                grid.innerHTML = '<div style="color: var(--text); grid-column: 1/-1; text-align: center; opacity: 0.6;">Товары скоро появятся</div>';
                return;
            }

            products.forEach(function(product) {
                let photo = product.media_urls && product.media_urls.length > 0 ? product.media_urls[0] : '';
                
                let card = document.createElement('div');
                card.className = 'glass tile';

                let imgHtml = photo 
                    ? `<div class="tile-img-wrap"><div class="tile-img" style="background-image: url('${photo}');"></div></div>`
                    : `<div class="tile-img-wrap" style="display:flex; align-items:center; justify-content:center; font-family:'Unbounded',sans-serif; font-size:12px; opacity:0.5;">77fayyes</div>`;

                card.innerHTML = `
                    ${imgHtml}
                    <div style="display:flex; justify-content:space-between; align-items:flex-end; margin-top:12px; width:100%;">
                        <span style="font-weight:500; font-size:14px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; max-width:65%;">${product.title}</span>
                        <span style="font-family:'Unbounded',sans-serif; font-weight:300; font-size:13px; opacity:0.9;">${product.price} UAH</span>
                    </div>
                `;

                card.addEventListener('click', function() {
                    openProductModal(product);
                });
                
                grid.appendChild(card);
            });
        } catch (e) {
            console.error("Ошибка загрузки товаров с API:", e);
        }
    }

    window.addEventListener('scroll', onScroll, {passive: true});
    window.addEventListener('resize', onScroll);
    
    document.addEventListener('DOMContentLoaded', function() {
        loadProducts();
    });

    tgt = cur = targetP(); apply(cur); onScroll();
})();